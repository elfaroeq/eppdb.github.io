<?php
// Load file koneksi.php
include "koneksi.php";

// Ambil Data yang Dikirim dari Form
$id = $_POST['id'];
$gelombang = $_POST['gelombang'];
$nik = $_POST['nik'];
$nisn = $_POST['nisn'];
$namapd = $_POST['namapd'];
$jk = $_POST['jk'];
$tempatlahirpd = $_POST['tempatlahirpd'];
$tanggallahirpd = $_POST['tanggallahirpd'];
$agama = $_POST['agama'];
$wapd = $_POST['wapd'];
$desapd = $_POST['desapd'];
$kecamatanpd = $_POST['kecamatanpd'];
$alamatpd = $_POST['alamatpd'];
$jenispd = $_POST['jenispd'];
$asalsekolah = $_POST['asalsekolah'];
$kk = $_POST['kk'];
$nikayah = $_POST['nikayah'];
$namaayah = $_POST['namaayah'];
$tempatlahirayah = $_POST['tempatlahirayah'];
$tanggallahirayah = $_POST['tanggallahirayah'];
$pendidikanayah = $_POST['pendidikanayah'];
$pekerjaanayah = $_POST['pekerjaanayah'];
$penghasilanayah = $_POST['penghasilanayah'];
$nikibu = $_POST['nikibu'];
$namaibu = $_POST['namaibu'];
$tempatlahiribu = $_POST['tempatlahiribu'];
$tanggallahiribu = $_POST['tanggallahiribu'];
$pendidikanibu = $_POST['pendidikanibu'];
$pekerjaanibu = $_POST['pekerjaanibu'];
$penghasilanibu = $_POST['penghasilanibu'];
$wawali = $_POST['wawali'];
$prestasi = $_POST['prestasi'];
$jaminan = $_POST['jaminan'];
$nomorbantuan = $_POST['nomorbantuan'];
$pkh = $_POST['pkh'];
$bantuan = $_POST['bantuan'];
$status = 1;
$keterangan = 1;


	// Proses simpan ke Database

	$query = "INSERT INTO siswa VALUES('".$id."', '".$gelombang."', '".$nik."', '".$nisn."', '".$namapd."', '".$jk."', '".$tempatlahirpd."','".$tanggallahirpd."','".$agama."','".$wapd."','".$desapd."','".$kecamatanpd."','".$alamatpd."','".$jenispd."', '".$asalsekolah."', '".$kk."', '".$nikayah."', '".$namaayah."', '".$tempatlahirayah."', '".$tanggallahirayah."', '".$pendidikanayah."', '".$pekerjaanayah."', '".$penghasilanayah."', '".$nikibu."', '".$namaibu."', '".$tempatlahiribu."', '".$tanggallahiribu."', '".$pendidikanibu."', '".$pekerjaanibu."', '".$penghasilanibu."', '".$wawali."', '".$prestasi."', '".$jaminan."','".$nomorbantuan."','".$pkh."','".$bantuan."','".$status."','".$keterangan."')";
	$sql = mysqli_query($connect, $query); // Eksekusi/ Jalankan query dari variabel $query

	if($sql){ // Cek jika proses simpan ke database sukses atau tidak
		// Jika Sukses, Lakukan :
		header("location: sukses.php"); // Redirect ke halaman index.php
	}else{
		// Jika Gagal, Lakukan :
		echo "Maaf, Terjadi kesalahan saat mencoba untuk menyimpan data ke database.";
		echo "<br><a href='tabelbk.php'>Kembali Ke Form</a>";
	}


?>



