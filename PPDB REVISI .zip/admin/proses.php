<?php
// Load file koneksi.php
include "../koneksi.php";
$id = $_GET['id'];
$user = $_POST['user'];
$pass = $_POST['pass'];
$tahun = $_POST['tahun'];
$nama = $_POST['nama'];
$visi = $_POST['visi'];
$misi = $_POST['misi'];
$lokasi = $_POST['lokasi'];
$embed = $_POST['embed'];
$email = $_POST['email'];
$wa = $_POST['wa'];

 // Cek apakah gambar berhasil diupload atau tidak
	// Proses simpan ke Database

	$query = "SELECT * FROM admin WHERE id='".$id."'";
		$sql = mysqli_query($connect, $query); // Eksekusi/Jalankan query dari variabel $query
		$data = mysqli_fetch_array($sql); // Ambil data dari hasil eksekusi $sql

		// Proses ubah data ke Database
		$query = "UPDATE admin SET user='".$user."', pass='".$pass."', tahun='".$tahun."', nama='".$nama."', visi='".$visi."', misi='".$misi."', lokasi='".$lokasi."', embed='".$embed."', email='".$email."', wa='".$wa."' WHERE id='".$id."'";
		$sql = mysqli_query($connect, $query); // Eksekusi/ Jalankan query dari variabel $query

		if($sql){ // Cek jika proses simpan ke database sukses atau tidak
			// Jika Sukses, Lakukan :
			header("location: pengaturan.php"); // Redirect ke halaman index.php
		}else{
			// Jika Gagal, Lakukan :
			echo "Maaf, Terjadi kesalahan saat mencoba untuk menyimpan data ke database.";
			echo "<br><a href='form_ubah.php'>Kembali Ke Form</a>";
		}
	
?>
