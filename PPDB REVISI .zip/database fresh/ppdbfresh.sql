-- phpMyAdmin SQL Dump
-- version 5.1.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 26 Feb 2022 pada 03.31
-- Versi server: 10.4.18-MariaDB
-- Versi PHP: 7.4.16

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ppdblama`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `admin`
--

CREATE TABLE `admin` (
  `id` int(11) NOT NULL,
  `user` varchar(100) NOT NULL,
  `pass` varchar(100) NOT NULL,
  `tahun` varchar(200) NOT NULL,
  `nama` varchar(300) NOT NULL,
  `visi` text NOT NULL,
  `misi` text NOT NULL,
  `lokasi` text NOT NULL,
  `embed` text NOT NULL,
  `email` varchar(300) NOT NULL,
  `wa` varchar(14) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `admin`
--

INSERT INTO `admin` (`id`, `user`, `pass`, `tahun`, `nama`, `visi`, `misi`, `lokasi`, `embed`, `email`, `wa`) VALUES
(1, 'admin', 'admin', '2020/2021', 'NAMA SEKOLAH', 'memajukan sekolah unggul dan berprestasi dalam bidang ilmu pengetahuan dan karater', 'mebangun karakter sekolah unggul dan berprestasi dalam bidang ilmu pengetahuan dan karater', 'Jln Malahayu, Kecamatan Banjarharjo Kabupaten Brebes', 'null', 'mtstatakustara@gmail.com', '08586116162');

-- --------------------------------------------------------

--
-- Struktur dari tabel `siswa`
--

CREATE TABLE `siswa` (
  `id` int(11) NOT NULL,
  `gelombang` varchar(300) NOT NULL,
  `nik` text NOT NULL,
  `nisn` text NOT NULL,
  `namapd` varchar(300) NOT NULL,
  `jk` varchar(150) NOT NULL,
  `tempatlahirpd` varchar(300) NOT NULL,
  `tanggallahirpd` varchar(300) NOT NULL,
  `agama` varchar(150) NOT NULL,
  `wapd` text NOT NULL,
  `desapd` varchar(300) NOT NULL,
  `kecamatanpd` varchar(300) NOT NULL,
  `alamatpd` text NOT NULL,
  `jenispd` varchar(300) NOT NULL,
  `asalsekolah` varchar(300) NOT NULL,
  `kk` text NOT NULL,
  `nikayah` text NOT NULL,
  `namaayah` varchar(300) NOT NULL,
  `tempatlahirayah` varchar(300) NOT NULL,
  `tanggallahirayah` varchar(300) NOT NULL,
  `pendidikanayah` varchar(300) NOT NULL,
  `pekerjaanayah` varchar(300) NOT NULL,
  `penghasilanayah` varchar(300) NOT NULL,
  `nikibu` text NOT NULL,
  `namaibu` varchar(300) NOT NULL,
  `tempatlahiribu` varchar(150) NOT NULL,
  `tanggallahiribu` varchar(300) NOT NULL,
  `pendidikanibu` varchar(150) NOT NULL,
  `pekerjaanibu` varchar(300) NOT NULL,
  `penghasilanibu` varchar(300) NOT NULL,
  `wawali` text NOT NULL,
  `prestasi` varchar(300) NOT NULL,
  `jaminan` text NOT NULL,
  `nomorbantuan` varchar(300) NOT NULL,
  `pkh` varchar(300) NOT NULL,
  `bantuan` varchar(300) NOT NULL,
  `status` varchar(150) NOT NULL,
  `Keterangan` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `siswa`
--
ALTER TABLE `siswa`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT untuk tabel `siswa`
--
ALTER TABLE `siswa`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
